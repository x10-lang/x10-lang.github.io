// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#ifndef SatX10__Solver_Minisat_2_2_0_h
#define SatX10__Solver_Minisat_2_2_0_h

#include "../../SatX10__Solver.h"

#include "../c++/minisat-2.2.0/core/Solver.h"
#include "../c++/minisat-2.2.0/utils/Options.h"


// Native c++ code for the x10 class Solver_Minisat_2_2_0
// Creates a solver object, parses commandline options, and reads CNF input file
class SatX10__Solver_Minisat_2_2_0 : public SatX10__Solver {
public:
    RTT_H_DECLS_CLASS

    // constructor
    SatX10__Solver_Minisat_2_2_0 (
            x10_int placeID,
            x10::lang::String* s,
            x10_int maxlen,
            x10_int outgoingClausesBufferSize,
            x10::array::Array<x10::lang::String* >* arguments) :
                SatX10__Solver(s->c_str(), maxlen) {

        // first parse command-line options; to do this, convert arguments into the usual argc, argv format
        int argc = arguments->FMGL(raw)->length() + 1;
        char** argv = convertX10StringArrayToCStyleArgvWithOffset(arguments);
        Minisat_2_2_0::parseOptions(argc, argv);
        // should normally have freed up the memory for argv here, but not worth the effort

        // now create the solver object
        solver = new Minisat_2_2_0::Solver(placeID, this, maxlen, outgoingClausesBufferSize);

        // parse CNF file
        solver->x10_parseDIMACS(s->c_str());

        // print instance information if this is place 0
        if (placeID == 0)
            printInstanceInfo();
    }

    // destructor
    virtual ~SatX10__Solver_Minisat_2_2_0() { }

    // _make for X10
    static SatX10__Solver_Minisat_2_2_0* _make(
            x10_int placeID,
            x10::lang::String* s,
            x10_int maxlen,
            x10_int outgoingClausesBufferSize,
            x10::array::Array<x10::lang::String* >* arguments) {

        SatX10__Solver_Minisat_2_2_0* self =
            new (x10aux::alloc<SatX10__Solver_Minisat_2_2_0>()) SatX10__Solver_Minisat_2_2_0(placeID, s, maxlen, outgoingClausesBufferSize, arguments);

        return self;
    }
};


#endif
