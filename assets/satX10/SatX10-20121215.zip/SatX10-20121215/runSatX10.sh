#!/bin/bash

# Solve example.cnf with 4 solvers ("places")
satx10=./SatX10
instance=example.cnf
nplaces=4
ppconfig=ppconfigs/example.ppconfig
maxclslen=10
outbuflen=10

# if running on a cluster with hosts specified in
# hostfiles/yourhosts.txt, simply add the following to the commandline
# below: X10_HOSTFILE=hostfiles/yourhosts.txt

# note: must have X10_NTHREADS=1 X10_STATIC_THREADS=true

echo "Executing: X10_NTHREADS=1 X10_STATIC_THREADS=true X10_NPLACES=$nplaces $satx10 $ppconfig $maxclslen $outbuflen $instance"
X10_NTHREADS=1 X10_STATIC_THREADS=true X10_NPLACES=$nplaces $satx10 $ppconfig $maxclslen $outbuflen $instance

