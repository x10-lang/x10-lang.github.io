// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#ifndef SatX10__Solver_h
#define SatX10__Solver_h

#include "x10/lang/VoidFun_0_1.h"
#include "x10/lang/Fun_0_0.h"
#include "x10/lang/X10Class.h"

#include "SolverX10Callback.h"
#include "SolverSatX10Base.h"

#include <string>


// A simple class to keep track of statistics related to x10 callbacks
class CallbackStats {
protected:
    int         numIncomingClauses;       // total number of incoming clauses incorporated
    vector<int> numIncomingClausesPerLen; // length histogram of incoming clauses
    int         numIncomingWithSelfInIDs; // number of incoming clauses with self in the list of IDs; discarded
    int         numIncomingDuplicates;    // number of duplicate incoming clauses detected and discarded
    int         numIncomingPassedThrough; // number of incoming clauses passed through as outgoing
    int         numOutgoingClauses;       // total number of outgoing clauses
    vector<int> numOutgoingClausesPerLen; // length histogram of outgoing clauses
    long		numClauseLengthTotalUsed;
    vector<int> numOutgoingClauseLength;  // histogram on length used

public:
    // constructor
    CallbackStats(const int _maxLenSharedClauses) :
        numIncomingClauses(0),
        numIncomingWithSelfInIDs(0),
        numIncomingPassedThrough(0),
        numOutgoingClauses(0),
        numClauseLengthTotalUsed(0)
    {
        numOutgoingClausesPerLen.resize(_maxLenSharedClauses + 1);
        numIncomingClausesPerLen.resize(_maxLenSharedClauses + 1);
        numOutgoingClauseLength.resize(_maxLenSharedClauses + 1);
    }

    // destructor
    ~CallbackStats() { }

    // member access methods
    int  getNumIncomingClauses       (void) const { return numIncomingClauses; }
    int  getNumIncomingWithSelfInIDs (void) const { return numIncomingWithSelfInIDs; }
    int  getNumIncomingDuplicates    (void) const { return numIncomingDuplicates; }
    int  getNumIncomingPassedThrough (void) const { return numIncomingPassedThrough; }
    int  getNumOutgoingClauses       (void) const { return numOutgoingClauses; }

    // other methods: update statistics
    void incrementIncoming(const int clauseLength);
    void incrementIncomingWithSelfInIDs() { numIncomingWithSelfInIDs++; }
    void incrementIncomingDuplicates()    { numIncomingDuplicates++; }
    void incrementIncomingPassedThrough() { numIncomingPassedThrough++; }
    void incrementOutgoing(const int clauseLength);
    void incrementUsedMaxLength(const int maxclauseLength);

    // other methods: print statistics
    void printStats(const SolverSatX10Base * const solver) const;
};


// Native c++ code for the x10 class 'Solver'
// Performs two types of functions:
//   1. Implements pure virtual callback methods for its base class SolverX10Callback
//      (unless they are solver specific, in which case solver specific classes
//       inheriting from this class implement it)
//   2. Implements routines that SatX10.x10 can use to interact with each solver
//      (which, in most cases, call the appropriate routing in the solver object)
//
class SatX10__Solver : public x10::lang::X10Class, public SolverX10Callback {
protected:
    SolverSatX10Base           *solver;
    int                         solveStatus;
    std::string                 instanceName;

    CallbackStats               cb_stats;

    x10::lang::VoidFun_0_1<x10::array::Array<x10_int>* >* closure1;
    x10::lang::Fun_0_0<x10_int>* closure2;

    char** convertX10StringArrayToCStyleArgvWithOffset(
        x10::array::Array<x10::lang::String*>* arguments, const char * filename = NULL);

    static const int            sep;   // the separator used when serializing vector<ClauseWithIDs>

public:
    RTT_H_DECLS_CLASS

    // X10 serialization requires these functions be stubbed out.
    // We never intend to serialize instances of SatX10_Solver or
    // its subclasses, so stub them out here to raise errors if they
    // are called.
    virtual x10aux::serialization_id_t _get_serialization_id() { abort(); return -1;}
    virtual void _serialize_body(x10aux::serialization_buffer &) { abort(); }
        
    // constructor
    SatX10__Solver (const char * const _instanceName, const int _maxLenSharedClauses) :
        solver(NULL),
        solveStatus(0),
        instanceName(_instanceName),
        cb_stats(abs(_maxLenSharedClauses)) { }    // note: _maxLenSharedClauses being negative signifies dynamic adjustment

    // destructor
    virtual ~SatX10__Solver() { if (solver != NULL) delete solver; }

    // type 1: implement for base class SolverX10Callback
    int x10_getRestart(void) const { return x10::lang::Fun_0_0<x10_int > ::__apply(closure2); }

    // type 1: implement for base class SolverX10Callback
    void x10_step(void) const { x10::lang::Runtime::probe(); }

    // type 1: implement for base class SolverX10Callback:
    //   process outgoing clauses: serialize all clauses in outgoingClauses
    //   for x10 and call the appropriate closure to share them
    void x10_processOutgoingClauses(const bool bProcessImmediately);

    // type 2: solve method, to be called by SatX10.x10
    x10_int solve(x10::lang::VoidFun_0_1<x10::array::Array<int>* > * closure1_,
                  x10::lang::Fun_0_0<x10_int>* closure2_);

    // type 2: kill method, to be called by SatX10.x10
    void kill(void) const { solver->x10_kill(); }

    // type 2: print instance information
    void printInstanceInfo(void) const;

    // type 2: print final result (solver statistics, sat/unsat, plus solution if requested)
    void printResults(const bool flag_printsoln = false) const;

    // type 2: print solver statistics
    void printStats(void) const { solver->x10_printStats(); }

    // type 2: print solution, assuming one has been found
    void printSolution(void) const { assert(solver != NULL); solver->x10_printSolution(); }

    // type 2: when an external clause arrives from another place, convert it to
    //   vector<int> and buffer it to be processed later by the solver
    void bufferIncomingClauses(x10::array::Array<x10_int>* clauses_);
};


inline void CallbackStats::incrementOutgoing(const int clauseLength) {
    while (clauseLength >= numOutgoingClausesPerLen.size())
        numOutgoingClausesPerLen.push_back(0);        // expand the vector to fit stats for size clauseLength

    ++ numOutgoingClauses;
    ++ numOutgoingClausesPerLen[clauseLength];
}

inline void CallbackStats::incrementIncoming(const int clauseLength) {
    while (clauseLength >= numIncomingClausesPerLen.size())
        numIncomingClausesPerLen.push_back(0);        // expand the vector to fit stats for size clauseLength
    ++ numIncomingClauses;
    ++ numIncomingClausesPerLen[clauseLength];
}

inline void CallbackStats::incrementUsedMaxLength(const int maxclauseLength) {
    while (maxclauseLength >= numOutgoingClauseLength.size())
        numOutgoingClauseLength.push_back(0);
    ++numOutgoingClauseLength[maxclauseLength];
    ++numClauseLengthTotalUsed;
}

// type 2: solve method, to be called by SatX10.x10
inline x10_int SatX10__Solver::solve (x10::lang::VoidFun_0_1<x10::array::Array<int>* >* closure1_,
                                      x10::lang::Fun_0_0<x10_int>* closure2_) {
    closure1 = closure1_;
    closure2 = closure2_;
    solveStatus = solver->x10_solve();
    return solveStatus;
}


#endif
