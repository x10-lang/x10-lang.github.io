// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#include "x10/array/Array.h"
#include "x10/lang/String.h"

#include "SatX10__Solver.h"
#include "utils.h"


void CallbackStats::printStats(const SolverSatX10Base * const solver) const {
    cout.setf(std::ios::fixed); cout.precision(2);  // set precision to 2 decimal digits

    cout << "c x10 shared clause %         : "
            << 100.0 * (getNumOutgoingClauses() / (double) solver->x10_nConflicts());
    if (solver->x10_isSharingCutoffDynamic())
        cout << " [ target " << 100.0 * solver->x10_getRatioSharedToLearnt() << " ]";
    cout << endl;

    cout << "c x10 outgoing clauses        : " << numOutgoingClauses << " [ ";
    for (unsigned i=1; i<numOutgoingClausesPerLen.size(); i++)
        cout << numOutgoingClausesPerLen[i] << ' ';
    cout << ']' << endl;

    cout << "c x10 incoming clauses        : " << numIncomingClauses << " [ ";
    for (unsigned i=1; i<numIncomingClausesPerLen.size(); i++)
        cout << numIncomingClausesPerLen[i] << ' ';
    cout << ']' << endl;

    if (solver->x10_isSharingCutoffDynamic()) {
        cout << "c x10 maxLength changes       : " << numClauseLengthTotalUsed << " [ ";
        for (unsigned i=1; i<numOutgoingClauseLength.size(); i++)
            cout << (numOutgoingClauseLength[i] / (double)numClauseLengthTotalUsed) * 100 << "% ";
        cout << ']' << endl;
    }
    cout << "c x10 incoming with self ID   : " << numIncomingWithSelfInIDs << endl;
}

// set value of static const member variables
const int SatX10__Solver::sep = 0;   // the separator used when serializing vector<ClauseWithIDs>

char** SatX10__Solver::convertX10StringArrayToCStyleArgvWithOffset(x10::array::Array<x10::lang::String*>* arguments, const char * filename) {
	const int gotFilename = (filename != NULL ? 1 : 0);
    const int argc = arguments->FMGL(raw)->length() + 1 + gotFilename;
    char** argv = new char*[argc];
    argv[0] = new char[5];
    strcpy(argv[0], "dummy");
    for (int i=1; i<argc-gotFilename; i++) {
        // convert arguments[i-1] to argv[i] here
        argv[i] = new char[64];
        strcpy(argv[i], arguments->__apply(i-1)->c_str());
    }
    if (gotFilename == 1) {
        argv[argc-1] = new char[512];
    	strcpy(argv[argc-1], filename);
    }
    return argv;
}

// type 1: implement for base class SolverX10Callback:
//   process outgoing clauses: serialize all clauses in solver->outgoingClauses
//   for x10 and call the appropriate closure;
//   also adjust shared clause max length if this method is being
//   called too often or too rarely
void SatX10__Solver::x10_processOutgoingClauses(bool bProcessImmediately) {
    if (!bProcessImmediately && solver->x10_getNumOutgoingClauses() < solver->x10_getOutgoingClausesBufferSize())
        // no need to do anything; simply return
        return;

    // go through all clauses with IDs in the outgoing clauses vector;
    // put them in a SINGLE std vector, separated by 'sep', with
    // clause and placeIDs themselves separated by sep
    vector<int> allClausesWithIDs;
    for (unsigned i=0; i<solver->x10_getNumOutgoingClauses(); i++) {
        vector<int> & clause = solver->x10_getOutgoingClause(i).clause;
        const vector<int> & IDs = solver->x10_getOutgoingClause(i).IDs;

        // append the clause to allClausesWithIDs
        assert(clause.size() > 0);
        allClausesWithIDs.insert(allClausesWithIDs.end(), clause.begin(), clause.end());
        // add the separator
        allClausesWithIDs.push_back(sep);

        // copy corresponding place IDs to allClausesWithIDs
        for (unsigned j=0 ; j<IDs.size() ; j++)
        	allClausesWithIDs.push_back(IDs[j] + 1);  // IDs are shifted by +1 when serializing
        // add the separator
        allClausesWithIDs.push_back(sep);

        // update x10 callback statistics
        cb_stats.incrementOutgoing(clause.size());
    }
    // empty the outgoing clauses vector
    solver->x10_clearOutgoingClauses();

    // Keep track on how often what max length has been used
    cb_stats.incrementUsedMaxLength(solver->x10_getMaxLenSharedClauses());

    // adjust x10_maxLenSharedClauses so that the ratio of outgoing buffer size and
    // number of conflicts encountered by the solver stays roughly constant (e.g., 5%)
    // NOTE: HARDWIRED bounds on adjustment: min=1, max=16
    if (solver->x10_isSharingCutoffDynamic()) {
        const double ratio = cb_stats.getNumOutgoingClauses() / (double) solver->x10_nConflicts();
        if (solver->x10_getMaxLenSharedClauses() < 16 && ratio < (solver->x10_getRatioSharedToLearnt() / 1.001))
            solver->x10_adjustMaxLenSharedClauses(+1);   // increase max length
        else if (solver->x10_getMaxLenSharedClauses() > 1 && ratio > (solver->x10_getRatioSharedToLearnt() * 1.001))
            solver->x10_adjustMaxLenSharedClauses(-1);   // decrease max length
    }

    // serialize allClausesWithIDs for x10
    x10::array::Array<x10_int>* clauses_ = x10::array::Array<x10_int>::_make(allClausesWithIDs.size());
    for (unsigned i=0 ; i<allClausesWithIDs.size() ; i++) {
        //(*clause_)[i] = toInt(clause[i]); // original
        //(*clause_).__set(i, toInt(clause[i])); // valid?
        clauses_->FMGL(raw)[(x10_int)i] = allClausesWithIDs[i];
    }

    // apply the closure to the clauses
    // IMPORTANT NOTE: when passing control to X10 to execute the closure, X10 may
    // very well process incoming messages, including the kill() message and the
    // bufferIncomingClauses() message! Hence, best to call the closure at the end
    // here, when we are not actively handling incoming or outgoing buffers
    x10::lang::VoidFun_0_1<x10::array::Array<x10_int>* >::__apply(closure1, clauses_);
}

// type 2: print instance information
void SatX10__Solver::printInstanceInfo(void) const {
    if (solver == NULL) {
        printf("WARNING: instance information can be printed only after a Solver object has been created. \n");
        return;
    }
    printf("c Instance information:\n");
    printf("c   filename                  : %s\n", instanceName.c_str());
    printf("c   number of variables       : %d\n", solver->x10_nVars());
    printf("c   number of clauses         : %d\n", solver->x10_nClauses());
}

// type 2: print final result (solver statistics, sat/unsat, plus solution if requested)
void SatX10__Solver::printResults(const bool flag_printsoln) const {
    // print result and possibly the solution, if found and asked for
    switch (solveStatus) {
    case -1:
        printf("s UNSATISFIABLE\n");
        break;

    case 0:
        printf("s UNKNOWN\n");
        break;

    case 1:
        printf("s SATISFIABLE\n");
        if (flag_printsoln)
            printSolution();
        break;

    default:
        abort();
    }

    // print solver's native statistics
    printStats();
    // print x10 callback statistics
    cb_stats.printStats(solver);

    // flush the output, just in case the process gets killed
    fflush(stdout);
}

// type 2: when an external clause (with IDs) arrives from another place, convert it to
//   ClauseWithIDs and buffer it to be processed later by the solver
void SatX10__Solver::bufferIncomingClauses(x10::array::Array<x10_int>* clauses_) {
    // de-serialize
    vector<int> allClausesWithIDs(clauses_->FMGL(raw)->length());
    //for (x10_int i=0 ; i<clause_->length() ; ++i) {
    for (x10_int i=0 ; i<clauses_->FMGL(raw)->length() ; i++) {
        //clause.push(toLit((*clause_)[i]));
        allClausesWithIDs[(unsigned)i] = clauses_->FMGL(raw)[i];
    }

    // push each clause and respective IDs on to the incoming clauses vector of the solver
    ClauseWithIDs clauseWithIDs;
    unsigned i = 0;
    while (i < allClausesWithIDs.size()) {
        bool discardClause = false;
        // clear fields (from possible prior use)
        clauseWithIDs.clause.clear();
        clauseWithIDs.IDs.clear();

        // first parse a clause
        assert(allClausesWithIDs[i] != sep);  // clause must have non-zero length
        while (allClausesWithIDs[i] != sep)
            clauseWithIDs.clause.push_back(allClausesWithIDs[i++]);
        // skip the separator
        i++;
        // now parse the corresponding IDs; if the ID of this place appears in the list,
        // this place has already seen (and even sent) this clause -- simply ignore it;
        // otherwise, push it to the incoming buffer
        while (allClausesWithIDs[i] != sep) {
            const int ID = allClausesWithIDs[i] - 1;      // IDs are shifted by -1 when deserializing
            i++;
            if (ID == solver->x10_getPlaceID()) {
                discardClause = true;
                while (allClausesWithIDs[i] != sep) i++;  // discard the remaining IDs
            }
        }
        // skip the separator
        i++;

        if (discardClause) {
            // nothing to be done
            cb_stats.incrementIncomingWithSelfInIDs();
            continue;
        }

        // push clause with IDs into solver's incoming buffer
        solver->x10_bufferIncomingClause(clauseWithIDs);
        // update x10 callback statistics
        cb_stats.incrementIncoming(clauseWithIDs.clause.size());
    }
}

RTT_CC_DECLS0(SatX10__Solver, "SatX10.Solver", x10aux::RuntimeType::class_kind)
